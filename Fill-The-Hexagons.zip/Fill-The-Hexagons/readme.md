About The Game

*This is 2 player game.

* Game has 21 hexagons.
Both Players has 10 turns and get their turns one after another starting from player 1.

* On their turn each player has to mark hexagon by clicking on it.

* Marking will start from 1 and will automatically increase till 10.

* Player 1 mark is represented by red color and Player 2 mark is represent by black color.

*When only one hexagon is left game is over and player with lowest score wins.

* Players score is sum of numbers in adjacent cell of unfilled cell marked by player previously.


*************************************************
*												   *
**** This Game Is Developed By Yogesh Pandey ****
*												   *
**************** Enjoy The Game! ****************
*												   *
*************************************************
